package com.example.gs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.gs.Constants
import com.example.gs.R
import com.example.gs.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private lateinit var bind: FragmentHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        bind = FragmentHomeBinding.inflate(inflater, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        bind.btnStart.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_escolhasFragment)
        }

        bind.btnTema.text = Constants.getThemeName()

        bind.btnTema.setOnClickListener {
            Constants.switchTheme()
            notifyActivityRecreate()
        }
    }

    private fun notifyActivityRecreate() {
        activity?.recreate()
    }
}
