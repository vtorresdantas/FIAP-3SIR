package com.example.gs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.gs.databinding.FragmentEscolhasBinding
import com.example.gs.databinding.FragmentHomeBinding
import com.example.gs.databinding.FragmentProdutividadeBinding


class ProdutividadeFragment : Fragment() {


    lateinit var bind : FragmentProdutividadeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_produtividade, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind = FragmentProdutividadeBinding.bind(view)

        val milhoValue = 2
        val sojaValue = 3
        val arrozValue = 4

        bind.milho.setOnClickListener {
            bind.milho.isChecked = true
            bind.soja.isChecked = false
            bind.arroz.isChecked = false
        }

        bind.soja.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = true
            bind.arroz.isChecked = false
        }

        bind.arroz.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = false
            bind.arroz.isChecked = true
        }

        bind.btnCalcular.setOnClickListener {
            val input01 = bind.input01.text.toString().toIntOrNull() ?: 0
            val input02 = bind.input02.text.toString().toIntOrNull() ?: 0

            val switchValue = when {
                bind.milho.isChecked -> milhoValue
                bind.soja.isChecked -> sojaValue
                bind.arroz.isChecked -> arrozValue
                else -> 0
            }

            val produtoAgricola = "kg de produto agrícola"
            val resultado = (input01 * switchValue + input02).toString() + " " + produtoAgricola

            bind.txtResultado.text = resultado.toString()
        }

        bind.btnVoltar.setOnClickListener {
            findNavController().navigate(R.id.action_produtividadeFragment_to_escolhasFragment)
        }
    }



}