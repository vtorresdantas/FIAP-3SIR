package com.example.gs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

enum class FertilizanteType(i: Int) {
    organicos(0),
    quimicos(1),
    liberacao(2)
}