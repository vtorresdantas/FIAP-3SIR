package com.example.gs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.gs.databinding.FragmentEscolhasBinding


class EscolhasFragment : Fragment() {

    lateinit var bind : FragmentEscolhasBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_escolhas, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind = FragmentEscolhasBinding.bind(view)

        val imageView: ImageView = view.findViewById(R.id.gif)
        Glide.with(this).load(R.drawable.seed1).into(imageView)

        bind.btnVerificar.setOnClickListener {
            val selectedOption = bind.radioGroup.checkedRadioButtonId
            when (selectedOption) {
                R.id.alternativa01 -> {
                    findNavController().navigate(R.id.action_escolhasFragment_to_produtividadeFragment)
                }
                R.id.alternativa02 -> {
                    findNavController().navigate(R.id.action_escolhasFragment_to_fertilizanteFragment)
                }
                R.id.alternativa03 -> {
                    findNavController().navigate(R.id.action_escolhasFragment_to_chuvasFragment)
                }
            }
        }
    }
}
