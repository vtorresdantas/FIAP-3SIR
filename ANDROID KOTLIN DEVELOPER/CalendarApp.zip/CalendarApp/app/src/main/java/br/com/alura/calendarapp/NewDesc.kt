package br.com.alura.calendarapp

import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.Data
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.RequiresApi
import br.com.alura.calendarapp.databinding.ActivityMainBinding
import br.com.alura.calendarapp.databinding.ActivityNewDescBinding
import com.example.intents_motivation.Desc
import java.time.Month


class NewDesc : AppCompatActivity() {

    private lateinit var databind: ActivityNewDescBinding
    private lateinit var descricao: Desc
    private lateinit var editDesc: EditText


    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        descricao = Desc()
        super.onCreate(savedInstanceState)
        databind = ActivityNewDescBinding.inflate(layoutInflater)
        setContentView(databind.root)

        val DateDay = intent.getIntExtra("dayOfMonth", -1)
        val DateMonth = intent.getIntExtra("DateMonth", -1)
        val DateYear = intent.getIntExtra("DateYear", -1)
        val DataAtual = DateDay.toString() + "/" + DateMonth.toString() + "/" + DateYear.toString()
        databind.appDate.text = DataAtual

        editDesc = databind.editDesc
        descricao = Desc()

        val saveBtn = databind.saveApp

        saveBtn.setOnClickListener {
            descricao.descricao = editDesc.text.toString()

            val resultIntent = Intent()
            resultIntent.putExtra("editDesc", descricao)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }

//        databind.saveApp.setOnClickListener {
//            Intent().apply {
//                descricao.descricao = editDesc.text.toString()
//
//                intent.putExtra("editDesc", descricao)
//                setResult(RESULT_OK, Intent())
//            }
//            this.finish()
//        }
//    }

}

