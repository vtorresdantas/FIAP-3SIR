package br.com.alura.calendarapp

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import br.com.alura.calendarapp.databinding.ActivityMainBinding
import com.example.intents_motivation.Desc
import com.example.strings_e_themes.Theme
import java.time.LocalDate
import java.time.Month


class MainActivity : AppCompatActivity() {

    private lateinit var databind: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        databind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(databind.root)

        val btnChange = databind.changeTheme

        btnChange.setOnClickListener{
            Theme.switchTheme()
            recreate()
        }

        databind.calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val date: LocalDate = LocalDate.of(year, Month.values().get(month), dayOfMonth)
            val selectedDates: String = date.toString()

            val intent = Intent(this, NewDesc::class.java)
            intent.putExtra("dayOfMonth", date.dayOfMonth)
            intent.putExtra("DateMonth",date.monthValue)
            intent.putExtra("DateYear",date.year)
            intent.putExtra("editDesc", databind.descDateView.text)

//            startActivity(intent)
            register.launch(intent)
        }


}
    private val register = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let { data ->
                val descExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    data.getParcelableExtra("editDesc", Desc::class.java)
                } else {
                    data.getParcelableExtra<Desc>("editDesc")
                }
                descExtra?.let {
                    databind.descDateView.text = descExtra.descricao
                    Log.d("NewDesc", "editDesc: $descExtra.descricao")

                }


            }
        }
    }
}