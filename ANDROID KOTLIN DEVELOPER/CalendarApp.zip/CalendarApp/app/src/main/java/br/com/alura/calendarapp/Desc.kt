package com.example.intents_motivation

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Desc(
    var descricao : String = "teste"
) : Parcelable
