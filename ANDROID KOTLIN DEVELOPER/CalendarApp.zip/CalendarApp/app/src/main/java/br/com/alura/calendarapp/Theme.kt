package com.example.strings_e_themes

import br.com.alura.calendarapp.R

object Theme {
    var currentTheme = R.style.Theme_CalendarApp
    private const val ACTUAL = R.style.Theme_CalendarApp
    private const val NEW = R.style.MeuTema

    fun switchTheme(){
        Theme.currentTheme = when (Theme.currentTheme){
            ACTUAL -> NEW
            NEW -> ACTUAL
            else -> -1
        }
    }
}