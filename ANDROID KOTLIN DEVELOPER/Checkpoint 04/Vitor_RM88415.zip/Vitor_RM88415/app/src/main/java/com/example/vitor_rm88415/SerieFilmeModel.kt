package com.example.vitor_rm88415

data class SerieFilmeModel(
    val Nome: String,
    val Genero: String,
    val Recomendaria: Boolean,
)
