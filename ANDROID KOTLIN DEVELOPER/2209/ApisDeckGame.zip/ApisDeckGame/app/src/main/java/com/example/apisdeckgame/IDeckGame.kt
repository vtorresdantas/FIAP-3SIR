package com.example.apisdeckgame

import com.example.apisdeckgame.model.CardModel
import retrofit2.Call
import com.example.apisdeckgame.model.DeckModel
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface IDeckGame {

    @GET("new/shuffle")
    fun getDeck(
        @Query("deck_count") deckCount: Int
    ): Call<DeckModel>

    @GET("{deck_id}/draw")
    fun getDeckCards(
        @Path("deck_id") deckId:String,
        @Query("count") cont:Int
    ): Call<CardModel>

}