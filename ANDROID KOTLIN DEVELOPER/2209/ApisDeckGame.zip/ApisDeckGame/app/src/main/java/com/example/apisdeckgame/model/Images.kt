package com.example.apisdeckgame.model

data class Images(
    val png: String,
    val svg: String
)