package com.example.recyclerpaises

data class PaisModel (
    val pais: String,
    val continente: String
)