package com.example.recyclerpaises

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.recyclerpaises.databinding.AddDialogFragmentBinding

class AddDialogFragment : DialogFragment() {

    lateinit var bind: AddDialogFragmentBinding
    var addListener: IAddPais? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        // Inicializa a variável 'bind' com a instância de AddDialogFragmentBinding
        bind = AddDialogFragmentBinding.inflate(layoutInflater)

        // Cria uma nova instância do AlertDialog.Builder associada à Activity atual
        val builder = AlertDialog.Builder(requireActivity())

        // Define a view do AlertDialog como o layout inflado de AddDialogFragmentBinding
        builder.setView(bind.root)
            // Define o botão positivo com texto "Salvar" e um OnClickListener
            .setPositiveButton("Salvar", DialogInterface.OnClickListener { dialog, id ->
                // Chama o método 'addPais' do 'IAddPais' (se não for nulo) com um novo 'PaisModel'
                addListener?.addPais(
                    PaisModel(
                        bind.txtPais.text.toString(),
                        bind.txtContinente.text.toString(),
                    )
                )
                // Fecha o diálogo
                dialog.cancel()
            })
            // Define o botão negativo com texto "Cancelar" e um OnClickListener
            .setNegativeButton("Cancelar") { dialog, _ ->
                // Fecha o diálogo
                dialog.cancel()
            }

        // Retorna o AlertDialog criado
        return builder.create()
    }

    companion object {
        // Método estático para criar uma nova instância de AddDialogFragment
        fun newInstance(
            listener: IAddPais
        ): AddDialogFragment {
            // Cria um novo Bundle e uma nova instância de AddDialogFragment
            val args = Bundle()
            val dialog = AddDialogFragment()

            // Define o listener 'addListener' da instância criada
            dialog.addListener = listener

            // Define os argumentos da instância
            dialog.arguments = args

            // Retorna a instância configurada
            return dialog
        }
    }
}
