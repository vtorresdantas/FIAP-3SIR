package com.example.recyclerpaises

interface IAddPais {
    fun addPais(pais: PaisModel)
}