// Pacote da aplicação
package com.example.recyclerpaises

// Importações necessárias
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.recyclerpaises.databinding.ActivityMainBinding
import kotlin.concurrent.fixedRateTimer

// Classe principal que herda de AppCompatActivity e implementa a interface IAddPais
class MainActivity : AppCompatActivity(), IAddPais {

    // Declaração de propriedade lateinit que será inicializada posteriormente
    lateinit var bind: ActivityMainBinding

    // Instância de um adaptador PaisesAdapter
    val adapter = PaisesAdapter()

    // Função chamada quando a Activity é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Infla o layout usando a ViewBinding e configura o conteúdo da tela
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        // Configura o RecyclerView com o adaptador e o layout manager StaggeredGrid
        bind.paisesRecycler.adapter = adapter
        bind.paisesRecycler.layoutManager =
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)

        // Adiciona uma lista de PaisesModel ao adaptador
        adapter.setList(mutableListOf(
            PaisModel("Brasil", "America do Sul"),
            PaisModel("Argentina", "America do Sul"),
            PaisModel("China", "Asia"),
            PaisModel("Egito", "Africa"),
            PaisModel("Portugal", "Europa")
        ))

        // Configura um OnClickListener para o botão addPaisBtn
        bind.addPaisBtn.setOnClickListener {
            // Cria e exibe um novo diálogo de adição de país
            AddDialogFragment.newInstance(this)
                .show(supportFragmentManager,"ADD_DIALOG")
        }

    }

    // Função de implementação da interface IAddPais para adicionar um país ao adaptador
    override fun addPais(pais: PaisModel) {
        adapter.addPais(pais)
    }
}
