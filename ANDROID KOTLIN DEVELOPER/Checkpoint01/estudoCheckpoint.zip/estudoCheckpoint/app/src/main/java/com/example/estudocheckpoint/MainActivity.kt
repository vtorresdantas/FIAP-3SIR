package com.example.estudocheckpoint

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    val btnClear = findViewById<Button>(R.id.btnClear)
    val btn =findViewById<Button>(R.id.button)
    val button2 =findViewById<Button>(R.id.button2)
    val textView = findViewById<TextView>(R.id.textView2)
    val imageView= findViewById<ImageView>(R.id.imageView)

        button2.setOnClickListener {
            imageView.setImageResource(R.drawable.car)
        }

        btn.setOnClickListener {
            textView.text = "Veja o nosso carro"
        }

        btnClear.setOnClickListener {
            imageView.setImageResource(R.drawable.img01)
            textView.text = "Imagem retornada"
        }

    }

}