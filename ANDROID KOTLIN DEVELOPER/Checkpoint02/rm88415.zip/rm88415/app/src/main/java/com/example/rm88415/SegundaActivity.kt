package com.example.rm88415

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SegundaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda)
    }
}