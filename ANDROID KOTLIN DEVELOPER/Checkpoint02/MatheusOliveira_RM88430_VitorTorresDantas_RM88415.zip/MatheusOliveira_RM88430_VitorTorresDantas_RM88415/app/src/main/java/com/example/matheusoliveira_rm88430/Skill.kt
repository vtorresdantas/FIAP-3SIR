package com.example.matheusoliveira_rm88430

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Skill(
    val nome: String,
    val descricao: String,
    var listaSkill: MutableList<String>
) : Parcelable
