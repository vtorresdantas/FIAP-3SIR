package com.example.matheusoliveira_rm88430

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.matheusoliveira_rm88430.databinding.ActivityMainBinding
import com.example.strings_e_themes.Theme

class MainActivity : AppCompatActivity() {

    private lateinit var databind: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        databind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(databind.root)

        val btnChange = databind.mudarTema

        btnChange.setOnClickListener{
            Theme.switchTheme()
            recreate()
        }


        databind.editarSkills.setOnClickListener {
            val intent = Intent(this, SegundaActivity::class.java)
            startActivity(intent)
        }

        val habilidadesTextView = findViewById<TextView>(R.id.habilidades)
        val habilidades = intent.getStringArrayListExtra("habilidades")
        habilidadesTextView.text = habilidades?.joinToString(", ")


    }


}