package com.example.matheusoliveira_rm88430

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.matheusoliveira_rm88430.databinding.ActivitySegundaBinding
import com.example.strings_e_themes.Theme

class SegundaActivity : AppCompatActivity() {

    private lateinit var databind: ActivitySegundaBinding
    private lateinit var skill: Skill

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        databind = ActivitySegundaBinding.inflate(layoutInflater)
        setContentView(databind.root)

        databind.skill1.isChecked = skill.listaSkill.contains("Bite")
        databind.skill2.isChecked = skill.listaSkill.contains("Ember")
        databind.skill3.isChecked = skill.listaSkill.contains("Fang")
        databind.skill4.isChecked = skill.listaSkill.contains("Blast")

        val listaCheckedSkill = mutableListOf<String>()

        // Atribui a lista temporária à lista de habilidades da instância de Skill
        skill.listaSkill = listaCheckedSkill

        // Envia a instância de Skill de volta ao MainActivity
        databind.updateSkill.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)

            val listaCheckedSkill = mutableListOf<String>()
            if (databind.skill1.isChecked) listaCheckedSkill.add("Bite")
            if (databind.skill2.isChecked) listaCheckedSkill.add("Ember")
            if (databind.skill3.isChecked) listaCheckedSkill.add("Fang")
            if (databind.skill4.isChecked) listaCheckedSkill.add("Blast")

            // Atribui a lista temporária à lista de habilidades da instância de Skill
            skill.listaSkill = listaCheckedSkill

            intent.putExtra("skill", skill)
            startActivity(intent)
        }


    }


}