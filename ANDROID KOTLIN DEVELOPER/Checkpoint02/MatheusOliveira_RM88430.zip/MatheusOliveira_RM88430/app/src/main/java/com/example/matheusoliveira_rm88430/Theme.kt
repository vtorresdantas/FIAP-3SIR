package com.example.strings_e_themes

import com.example.matheusoliveira_rm88430.R

object Theme {
    var currentTheme = R.style.Theme_MatheusOliveira_RM88430
    private const val ACTUAL = R.style.Theme_MatheusOliveira_RM88430
    private const val NEW = R.style.newTema

    fun switchTheme(){
        Theme.currentTheme = when (Theme.currentTheme){
            ACTUAL -> NEW
            NEW -> ACTUAL
            else -> -1
        }
    }
}