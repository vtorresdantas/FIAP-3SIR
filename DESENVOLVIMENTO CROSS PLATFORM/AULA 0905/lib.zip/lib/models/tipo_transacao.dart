enum TipoTransacao { receita, despesa }
