import 'package:flutter/material.dart';
import 'package:teste/models/tipo_transacao.dart';

class Categoria {
  String id;
  String nome;
  IconData icone;
  Color cor;
  TipoTransacao transacao;

  Categoria({
    required this.id,
    required this.nome,
    required this.icone,
    required this.cor,
    required this.transacao,
  });
}
