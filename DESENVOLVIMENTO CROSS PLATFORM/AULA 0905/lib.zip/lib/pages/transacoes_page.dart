import 'package:flutter/material.dart';

class TransacoesPage extends StatefulWidget {
  const TransacoesPage();

  @override
  State<TransacoesPage> createState() => _TransacoesPageState();
}

class _TransacoesPageState extends State<TransacoesPage> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Transações'));
  }
}
