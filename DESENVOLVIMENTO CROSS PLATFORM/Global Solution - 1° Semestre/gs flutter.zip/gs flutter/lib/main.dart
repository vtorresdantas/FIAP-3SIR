import 'package:flutter/material.dart';
import 'package:gs/pages/home_page.dart';
import 'package:gs/pages/analise_plantacao01.dart';
import 'package:gs/pages/analise_plantacao02.dart';
import 'package:gs/pages/analise_plantacao03.dart';
import 'package:gs/pages/analise_plantacao04.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GS Flutter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        'lib/pages/analise_plantacao01.dart': (context) => AnalisePlantacao01Page(),
        'lib/pages/analise_plantacao02.dart': (context) => AnalisePlantacao02Page(),
        'lib/pages/analise_plantacao03.dart': (context) => AnalisePlantacao03Page(),
        'lib/pages/analise_plantacao04.dart': (context) => AnalisePlantacao04Page(),
      },
    );
  }
}
