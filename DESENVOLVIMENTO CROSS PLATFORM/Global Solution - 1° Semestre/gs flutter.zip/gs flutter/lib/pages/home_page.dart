import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'historico_page.dart';
import 'imagens_page.dart';

class HomePage extends StatefulWidget {
  const HomePage();
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int page = 0;

  final List<Widget> pages = [
    _HomePageContent(),
    ImagensPage(),
    HistoricoPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('HomePage'),
      // ),
      body: pages[page],
      bottomNavigationBar: getBottomNavigationBar(),
    );
  }

  Widget getBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: page,
      onTap: (paginaSelecionada) {
        setState(() {
          page = paginaSelecionada;
        });
      },
      items: [
        BottomNavigationBarItem(
          icon: Icon(Ionicons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.glasses_outline),
          label: 'Analise de imagens',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.wallet_outline),
          label: 'Historico imagens',
        ),
      ],
      type: BottomNavigationBarType.fixed,
    );
  }
}

class _HomePageContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 16),
        Center(
          child: Image.asset(
            'assets/images/drone_monitora.jpg', 
            height: 400,
            width: 400,
          ),
        ),
        SizedBox(height: 16),
        Center(
          child: Text(
            'Bem-vindo ao App de monitoração de plantações com drones!',
            style: TextStyle(fontSize: 24),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(height: 16),
        Center(
          child: Text(
            'Potencialize seus cultivos com o poder da tecnologia: ' +
                'Monitoramento inteligente de plantações com drones e IA ' +
                'para identificação precisa de culturas, pragas, doenças, ' +
                'deficiências nutricionais e necessidades de irrigação. Utilize as abas abaixo para navegação',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}
