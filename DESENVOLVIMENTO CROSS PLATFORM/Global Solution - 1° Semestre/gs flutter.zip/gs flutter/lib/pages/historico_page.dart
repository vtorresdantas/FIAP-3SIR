import 'package:flutter/material.dart';
import '../models/historicoImages.dart';

class HistoricoPage extends StatefulWidget {
  const HistoricoPage();

  @override
  State<HistoricoPage> createState() => _HistoricoPageState();
}

class _HistoricoPageState extends State<HistoricoPage> {
  List<HistoricoImages> historicoImagesList = droneHistorico.values.toList();
  String searchId = '';

  List<HistoricoImages> filteredHistoricoImages() {
    if (searchId.isEmpty) {
      return historicoImagesList;
    } else {
      return historicoImagesList
          .where((historico) => historico.id.toLowerCase().contains(searchId.toLowerCase()))
          .toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bem-vindo ao Histórico de Imagens!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    searchId = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Buscar por ID',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: filteredHistoricoImages().length,
                itemBuilder: (context, index) {
                  final historico = filteredHistoricoImages()[index];

                  return ListTile(
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    leading: Container(
                      width: 220,
                      child: Image.asset(
                        historico.caminhoImagem,
                        fit: BoxFit.cover,
                        height: 450,
                      ),
                    ),
                    title: Text(
                      'ID: ${historico.id}',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 8),
                        Text(
                          historico.titulo,
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.normal),
                        ),
                        SizedBox(height: 8),
                        Text(
                          historico.data,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.normal),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
