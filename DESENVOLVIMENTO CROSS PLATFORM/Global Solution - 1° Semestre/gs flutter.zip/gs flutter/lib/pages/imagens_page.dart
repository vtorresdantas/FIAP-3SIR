import 'package:flutter/material.dart';

import '../models/droneImages.dart';
import 'analise_plantacao01.dart';

class ImagensPage extends StatefulWidget {
  const ImagensPage();

  @override
  State<ImagensPage> createState() => _ImagensPageState();
}

class _ImagensPageState extends State<ImagensPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Analise de imagens'),
      ),
      body: GridView.count(
        primary: false,
        padding: const EdgeInsets.all(20),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        crossAxisCount: 2,
        children: droneIds.values.map((drone) {
          return Container(
            padding: const EdgeInsets.all(5),
            child: Column(
              children: [
                Image.asset(
                  drone.caminhoImagem,
                  height: 350,
                  width: 350,
                ),
                Text(
                  'Id: ${drone.id}\nLatitude: ${drone.latitude}\nLongitude: ${drone.longitude}',
                  style: TextStyle(fontSize: 20),
                ),
                Text(''),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pushNamed(context, drone.caminhoPagina);
                  },
                  icon: Icon(Icons.search, size: 18),
                  label: Text("Analisar plantação"),
                )
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
