import 'package:flutter/material.dart';

import 'imagens_page.dart';

class AnalisePlantacao01Page extends StatefulWidget {
  const AnalisePlantacao01Page();

  @override
  State<AnalisePlantacao01Page> createState() => _AnalisePlantacao01PageState();
}

class _AnalisePlantacao01PageState extends State<AnalisePlantacao01Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Análise de Plantação 01'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bem-vindo à Análise de Imagens!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/images/plantacao01.jpg',
              width: 300,
              height: 300,
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'A plantação está aparentemente saudável, porém foi analisado e alertado para os seguintes problemas:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text:
                          '• Pragas de insetos: A plantação está enfrentando uma infestação de insetos que estão causando danos significativos às culturas, resultando na perda de rendimento e qualidade dos produtos.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Deficiência de nutrientes: A plantação está sofrendo com deficiência de nutrientes essenciais, como nitrogênio, fósforo ou potássio, o que leva ao crescimento lento das plantas, folhas amareladas e menor produtividade.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Doenças fúngicas: A plantação está sendo afetada por doenças fúngicas, como mofo ou ferrugem, que estão se espalhando rapidamente, causando manchas nas folhas, apodrecimento dos frutos e redução da qualidade dos produtos colhidos.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => ImagensPage()),
                );
              },
              child: Text('Voltar para a página de análise'),
            ),
          ],
        ),
      ),
    );
  }
}
