import 'package:flutter/material.dart';

import 'imagens_page.dart';

class AnalisePlantacao03Page extends StatefulWidget {
  const AnalisePlantacao03Page();

  @override
  State<AnalisePlantacao03Page> createState() => _AnalisePlantacao03PageState();
}

class _AnalisePlantacao03PageState extends State<AnalisePlantacao03Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Análise de Plantação 03'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bem-vindo à Análise de Imagens!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/images/plantacao03.jpg',
              width: 300,
              height: 300,
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'A plantação está aparentemente saudável, porém foi analisado e alertado para os seguintes problemas:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text:
                          '• Pragas de insetos: A plantação está enfrentando uma infestação de insetos que estão causando danos significativos às culturas, resultando na perda de rendimento e qualidade dos produtos.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Deficiência de nutrientes: A plantação está sofrendo com deficiência de nutrientes essenciais, como nitrogênio, fósforo ou potássio, o que leva ao crescimento lento das plantas, folhas amareladas e menor produtividade.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Doenças fúngicas: A plantação está sendo afetada por doenças fúngicas, como mofo ou ferrugem, que estão se espalhando rapidamente, causando manchas nas folhas, apodrecimento dos frutos e redução da qualidade dos produtos colhidos.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Falta de irrigação: A plantação está sofrendo com falta de irrigação adequada, resultando em estresse hídrico nas plantas, folhas murchas e menor desenvolvimento.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    TextSpan(
                      text:
                          '• Ervas daninhas: A plantação está infestada de ervas daninhas, que estão competindo por recursos com as plantas cultivadas, diminuindo seu crescimento e produtividade.\n',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => ImagensPage()),
                );
              },
              child: Text('Voltar para a página de análise'),
            ),
          ],
        ),
      ),
    );
  }
}
