class HistoricoImages {
  final String id;
  final String titulo;
  final String data;
  final String caminhoImagem;

  const HistoricoImages(this.id, this.titulo, this.data, this.caminhoImagem);
}

const Map<String, HistoricoImages> droneHistorico = {
  "image01": HistoricoImages('3748521221618', '37°48\'52"N', 'Dia: 04/03/2020','assets/images/hist01.jpg'),
  "image02": HistoricoImages('40425173598', '40°42\'51"S', 'Dia: 10/05/2022','assets/images/hist02.jpg'),
  "image03": HistoricoImages('5130120739', '51°30\'12"N', 'Dia: 28/11/2023','assets/images/hist03.jpg'),
  "image04": HistoricoImages('3351301511245', '33°51\'30"S', 'Dia: 03/09/2035','assets/images/hist04.jpg'),
  "image": HistoricoImages('59993022101545', '59°99\'22"S', 'Dia: 03/10/2015','assets/images/hist05.jpg'),
};
