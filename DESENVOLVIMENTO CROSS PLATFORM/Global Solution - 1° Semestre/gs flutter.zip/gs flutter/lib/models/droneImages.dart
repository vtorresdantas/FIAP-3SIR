class DroneImages {
  final String id;
  final String latitude;
  final String longitude;
  final String caminhoImagem;
  final String caminhoPagina;

  const DroneImages(this.id, this.latitude, this.longitude, this.caminhoImagem, this.caminhoPagina);
}

const Map<String, DroneImages> droneIds = {
  "image01": DroneImages('3748521221618', '37°48\'52"N', '122°16\'18"W','assets/images/plantacao01.jpg', 'lib/pages/analise_plantacao01.dart'),
  "image02": DroneImages('40425173598', '40°42\'51"S', '73°59\'8"E','assets/images/plantacao02.jpg','lib/pages/analise_plantacao02.dart'),
  "image03": DroneImages('5130120739', '51°30\'12"N', '0°7\'39"W','assets/images/plantacao03.jpg','lib/pages/analise_plantacao03.dart'),
  "image04": DroneImages('3351301511245', '33°51\'30"S', '151°12\'45"E','assets/images/plantacao04.jpg','lib/pages/analise_plantacao04.dart'),
};
