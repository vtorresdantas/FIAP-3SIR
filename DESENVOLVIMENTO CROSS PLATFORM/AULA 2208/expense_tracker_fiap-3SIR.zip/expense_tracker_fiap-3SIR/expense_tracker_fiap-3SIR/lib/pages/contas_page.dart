import 'package:expense_tracker/components/conta_item.dart';
import 'package:expense_tracker/models/conta.dart';
import 'package:flutter/material.dart';

import '../repository/contas_repositrory.dart';

class ContasPage extends StatefulWidget {
  const ContasPage({super.key});

  @override
  State<ContasPage> createState() => _ContasPageState();
}

class _ContasPageState extends State<ContasPage> {
  final futureContas = ContasRepository().listarContas();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Contas'),
        ),
        body: FutureBuilder<List<Conta>>(
            future: futureContas,
            builder: (context, snapshot) {
              //Future Não Concluída
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              //Future Concluída com erro
              else if (snapshot.hasError) {
                return Center(
                  child: Text('Ocorreu um erro'),
                );
              }
              //Future Concluída com sucesso, sem dados
              else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return Center(
                  child: Text('Nenhuma conta cadastrada'),
                );
              }

              //Future Concluída com sucesso
              else {
                List<Conta> contas = snapshot.data ?? [];

                return ListView.separated(
                  itemCount: contas.length,
                  itemBuilder: (context, index) {
                    final conta = contas[index];
                    return ContaItem(conta: conta);
                  },
                  separatorBuilder: (context, index) {
                    return const Divider();
                  },
                );
              }
            }));
  }
}
