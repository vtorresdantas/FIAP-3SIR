package br.com.fiap.exemplo.exemplo.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import br.com.fiap.exemplo.exemplo.models.Clientes;
import br.com.fiap.exemplo.exemplo.models.Produto;
import br.com.fiap.exemplo.exemplo.models.Categoria;

@Controller
@RequestMapping("/cliente")
public class ClientesController {

	@GetMapping("")
	public ModelAndView get() {
		ModelAndView model = new ModelAndView("cliente/index");
		List<Clientes> listaClientes = new ArrayList<Clientes>();

		/*Clientes clienteUm = new Clientes();
		clienteUm.setNome("Teruya");
		clienteUm.setIdade(1);
		clienteUm.setDocumento("39578515");

		Clientes clienteDois = new Clientes();
		clienteDois.setNome("Teruya");
		clienteDois.setIdade(2);
		clienteDois.setDocumento("39578515");

		Clientes clienteTres = new Clientes();
		clienteTres.setNome("Teruya");
		clienteTres.setIdade(3);
		clienteTres.setDocumento("39578515");

		listaClientes.add(clienteUm);
		listaClientes.add(clienteDois);
		listaClientes.add(clienteTres);*/

		model.addObject("Clientes", listaClientes);
		return model;
	}

	@GetMapping("/edit/{idade}")
	public String getById(Model model, @PathVariable("idade") Integer idIdade) {
		// model.addAttribute("")
		return "cliente/edit";

	}

	@GetMapping("/create")
	public String create() {
		return "produto/create";
	}

	@PostMapping("/create")
	public String create(@ModelAttribute("produto") Produto objProduto) {
		// enviar para base de dados

		System.out.println(objProduto.getId());
		System.out.println(objProduto.getNome());

		return "redirect:/produto";
	}

	@GetMapping("/categoria")
	@ResponseBody
	public Categoria getCategoria() {
		Categoria categoria = new Categoria();
		categoria.setDescricao("masculino");
		categoria.setId(1);

		return categoria;
	}

}
