package br.com.fiap.exemplo.exemplo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.exemplo.exemplo.models.Clientes;

public interface ClienteRepository extends JpaRepository<Clientes, String, Integer, String> {

}
