const express = require('express')
const app = express()
app.use(express.json())

app.use(express.urlencoded({
    extended: true
}))

//registro da model
required('./models/produto')

//rotas
const produtoRouter = require('./routers/produto-route')


const index = require('./routers/index')

app.use('/', index)
app.use('/produto', produtoRouter)

module.exports = app;