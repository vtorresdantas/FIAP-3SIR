# EndPoint de departamento pessoal

- Endpoint utilizado para API com Código em JavaScript referente ao checkpoint01 da matéria de microserviços

- Acesso HTTP: localhost:3000



