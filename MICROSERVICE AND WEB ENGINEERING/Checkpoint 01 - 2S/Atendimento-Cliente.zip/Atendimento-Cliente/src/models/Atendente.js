const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const schema = new Schema({
    idAtendente :{
        type: Number,
        required: true
    },
    idPessoa :{
        type: Number,
        required: true
    },
    idSetor :{
        type: Number,
        required: true
    },
    ativo: {
        type: Boolean,
        required: true,
        default: true
    }
});

module.exports = mongoose.model('Atendente', schema)