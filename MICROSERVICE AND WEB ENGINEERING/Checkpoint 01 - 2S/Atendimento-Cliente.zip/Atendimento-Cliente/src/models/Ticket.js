const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const schema = new Schema({
    idTicket :{
        type: Number,
        required: true
    },
    idAtendente :{
        type: Number,
        required: true
    },
    idCliente: {
        type: Number,
        required: true,
    },
    titulo :{
        type: String,
        required: true
    },
    telefone: {
        type: String,
        required: true,
    },
    ativo: {
        type: Boolean,
        required: true,
        default: true
    }
});

module.exports = mongoose.model('Ticket', schema)