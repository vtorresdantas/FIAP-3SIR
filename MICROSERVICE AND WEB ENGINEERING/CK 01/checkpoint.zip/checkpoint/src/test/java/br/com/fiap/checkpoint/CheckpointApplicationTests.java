package br.com.fiap.checkpoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckpointApplicationTests {

	@Test
	void contextLoads() {
	}

}
