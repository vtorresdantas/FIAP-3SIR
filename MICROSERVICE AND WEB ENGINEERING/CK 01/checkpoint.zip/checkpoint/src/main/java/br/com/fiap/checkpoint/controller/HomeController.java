package br.com.fiap.checkpoint.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("mensagem", "Bem vindo ao nosso checkpoint :)");
		model.addAttribute("nome", "Matheus de O.");
		model.addAttribute("nome1", "Vitor Torres.");

		return "home";
	}
}
