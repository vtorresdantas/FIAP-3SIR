package br.com.fiap.checkpoint.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.checkpoint.model.Fornecedor;

public interface FornecedorRepository extends JpaRepository<Fornecedor, Long>{

}
